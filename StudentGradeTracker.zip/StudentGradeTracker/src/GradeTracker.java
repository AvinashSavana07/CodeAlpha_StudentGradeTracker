import java.util.ArrayList;
import java.util.List;

public class GradeTracker {
    private final ArrayList<Student> students = new ArrayList<>();

    public void addStudent(Student s) {
        if (s != null) students.add(s);
    }

    public List<Student> getStudents() {
        return students; // fine for this project; could wrap unmodifiable if needed
    }

    public int getOverallHighestScore() {
        int max = Integer.MIN_VALUE;
        boolean hasAny = false;
        for (Student s : students) {
            if (!s.getGrades().isEmpty()) {
                max = Math.max(max, s.getHighest());
                hasAny = true;
            }
        }
        return hasAny ? max : 0;
    }

    public int getOverallLowestScore() {
        int min = Integer.MAX_VALUE;
        boolean hasAny = false;
        for (Student s : students) {
            if (!s.getGrades().isEmpty()) {
                min = Math.min(min, s.getLowest());
                hasAny = true;
            }
        }
        return hasAny ? min : 0;
    }

    public String generateReport() {
        StringBuilder sb = new StringBuilder("\n===== Student Grade Report =====\n");
        for (Student s : students) {
            sb.append("Name: ").append(s.getName()).append("\n");
            sb.append("Grades: ").append(s.getGrades()).append("\n");
            sb.append(String.format("Average: %.2f | Highest: %d | Lowest: %d\n",
                    s.getAverage(), s.getHighest(), s.getLowest()));
            sb.append("-----------------------------------\n");
        }
        sb.append("Overall Highest Score: ").append(getOverallHighestScore()).append("\n");
        sb.append("Overall Lowest Score: ").append(getOverallLowestScore()).append("\n");
        return sb.toString();
    }
}
