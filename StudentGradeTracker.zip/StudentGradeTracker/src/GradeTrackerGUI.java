import javax.swing.*;
import java.awt.*;
import java.util.Objects;

public class GradeTrackerGUI extends JFrame {
    private final GradeTracker tracker = new GradeTracker();

    // UI elements
    private final JTextField nameField = new JTextField(12);
    private final JTextField gradeField = new JTextField(5);
    private final DefaultListModel<Integer> gradeListModel = new DefaultListModel<>();
    private final JList<Integer> gradeList = new JList<>(gradeListModel);
    private final JTextArea reportArea = new JTextArea(10, 50);

    private Student currentStudent = null;

    public GradeTrackerGUI() {
        setTitle("Student Grade Tracker (GUI)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(720, 520);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // --- Top: student controls ---
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Student Name:"));
        top.add(nameField);
        JButton newStudentBtn = new JButton("Add/Select Student");
        top.add(newStudentBtn);

        // --- Center: grades list + input ---
        JPanel center = new JPanel(new BorderLayout(6, 6));
        center.setBorder(BorderFactory.createTitledBorder("Grades for current student"));
        gradeList.setVisibleRowCount(8);
        center.add(new JScrollPane(gradeList), BorderLayout.CENTER);

        JPanel gradeInput = new JPanel(new FlowLayout(FlowLayout.LEFT));
        gradeInput.add(new JLabel("Grade (0-100):"));
        gradeInput.add(gradeField);
        JButton addGradeBtn = new JButton("Add Grade");
        JButton removeGradeBtn = new JButton("Remove Selected");
        gradeInput.add(addGradeBtn);
        gradeInput.add(removeGradeBtn);
        center.add(gradeInput, BorderLayout.SOUTH);

        // --- Bottom: report ---
        JPanel bottom = new JPanel(new BorderLayout(6, 6));
        JButton showReportBtn = new JButton("Generate Report");
        bottom.add(showReportBtn, BorderLayout.NORTH);
        reportArea.setEditable(false);
        bottom.add(new JScrollPane(reportArea), BorderLayout.CENTER);

        add(top, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);

        // --- Actions ---
        newStudentBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a student name.");
                return;
            }
            // Find existing student by name or create a new one
            currentStudent = tracker.getStudents().stream()
                    .filter(s -> Objects.equals(s.getName(), name))
                    .findFirst()
                    .orElseGet(() -> {
                        Student s = new Student(name);
                        tracker.addStudent(s);
                        return s;
                    });

            gradeListModel.clear();
            for (int g : currentStudent.getGrades()) gradeListModel.addElement(g);
            reportArea.setText("Selected: " + currentStudent.getName() + "\n");
            gradeField.requestFocusInWindow();
        });

        addGradeBtn.addActionListener(e -> {
            if (currentStudent == null) {
                JOptionPane.showMessageDialog(this, "Add/Select a student first.");
                return;
            }
            String text = gradeField.getText().trim();
            try {
                int grade = Integer.parseInt(text);
                if (grade < 0 || grade > 100) {
                    JOptionPane.showMessageDialog(this, "Enter a number between 0 and 100.");
                    return;
                }
                currentStudent.addGrade(grade);
                gradeListModel.addElement(grade);
                gradeField.setText("");
                gradeField.requestFocusInWindow();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid number.");
            }
        });

        removeGradeBtn.addActionListener(e -> {
            if (currentStudent == null) return;
            int idx = gradeList.getSelectedIndex();
            if (idx >= 0) {
                // simple remove: rebuild student's grades from list model
                gradeListModel.remove(idx);
                // sync back to student
                // (for a tiny app, easiest is clear and re-add)
                try {
                    java.lang.reflect.Field f = Student.class.getDeclaredField("grades");
                    f.setAccessible(true);
                    java.util.ArrayList<Integer> list = new java.util.ArrayList<>();
                    for (int i = 0; i < gradeListModel.size(); i++) list.add(gradeListModel.get(i));
                    f.set(currentStudent, list);
                } catch (Exception ignored) {
                    // if reflection fails, just regenerate report later (not critical)
                }
            }
        });

        showReportBtn.addActionListener(e -> reportArea.setText(tracker.generateReport()));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GradeTrackerGUI().setVisible(true));
    }
}
