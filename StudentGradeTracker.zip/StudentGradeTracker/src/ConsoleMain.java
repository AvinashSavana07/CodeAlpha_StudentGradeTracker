import java.util.Scanner;

public class ConsoleMain {

    private static int readIntInRange(Scanner sc, String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String line = sc.nextLine().trim();
            try {
                int val = Integer.parseInt(line);
                if (val < min || val > max) {
                    System.out.println("Please enter a number between " + min + " and " + max + ".");
                    continue;
                }
                return val;
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    private static int readPositiveInt(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = sc.nextLine().trim();
            try {
                int val = Integer.parseInt(line);
                if (val <= 0) {
                    System.out.println("Please enter a positive number.");
                    continue;
                }
                return val;
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        GradeTracker tracker = new GradeTracker();

        System.out.println("=== Student Grade Tracker (Console) ===");
        int numStudents = readPositiveInt(sc, "Enter number of students: ");

        for (int i = 0; i < numStudents; i++) {
            System.out.print("\nEnter student name: ");
            String name = sc.nextLine().trim();
            while (name.isEmpty()) {
                System.out.print("Name cannot be empty. Enter student name: ");
                name = sc.nextLine().trim();
            }

            Student student = new Student(name);
            int numGrades = readPositiveInt(sc, "Enter number of grades for " + name + ": ");

            for (int j = 0; j < numGrades; j++) {
                int grade = readIntInRange(sc, "Enter grade " + (j + 1) + " (0-100): ", 0, 100);
                student.addGrade(grade);
            }
            tracker.addStudent(student);
        }

        System.out.println(tracker.generateReport());
        sc.close();
    }
}
