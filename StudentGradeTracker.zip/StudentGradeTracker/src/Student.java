import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Student {
    private final String name;
    private final ArrayList<Integer> grades = new ArrayList<>();

    public Student(String name) {
        this.name = name;
    }

    public void addGrade(int grade) {
        grades.add(grade);
    }

    public String getName() {
        return name;
    }

    public List<Integer> getGrades() {
        return Collections.unmodifiableList(grades);
    }

    public double getAverage() {
        if (grades.isEmpty()) return 0.0;
        int sum = 0;
        for (int g : grades) sum += g;
        return (double) sum / grades.size();
    }

    public int getHighest() {
        int max = Integer.MIN_VALUE;
        for (int g : grades) if (g > max) max = g;
        return grades.isEmpty() ? 0 : max;
    }

    public int getLowest() {
        int min = Integer.MAX_VALUE;
        for (int g : grades) if (g < min) min = g;
        return grades.isEmpty() ? 0 : min;
    }
}
